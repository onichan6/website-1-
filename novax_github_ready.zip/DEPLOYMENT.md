# Deployment

Recommended architecture: GitHub -> Vercel/Node host + managed PostgreSQL.

Set `DATABASE_URL`, `JWT_SECRET`, `ADMIN_EMAIL`, and `ADMIN_PASSWORD` as deployment secrets.

For real crypto operations, replace the internal ledger demo with a properly secured custody/blockchain service and add the required compliance and security controls.
