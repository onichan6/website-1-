import { cookies } from "next/headers";
import { jwtVerify, SignJWT } from "jose";
const secret = new TextEncoder().encode(process.env.JWT_SECRET || "dev-secret");
export async function createSession(userId:string){
  return new SignJWT({userId}).setProtectedHeader({alg:"HS256"}).setIssuedAt().setExpirationTime("7d").sign(secret);
}
export async function getUserId(){
  const token=(await cookies()).get("session")?.value;
  if(!token) return null;
  try { return (await jwtVerify(token,secret)).payload.userId as string; } catch { return null; }
}
