import "./globals.css";
import Link from "next/link";
export default function Layout({children}:{children:React.ReactNode}){return <><nav className="nav"><Link className="brand" href="/">NovaX</Link><div className="row"><Link href="/dashboard">Dashboard</Link><Link className="btn" href="/login">Login</Link></div></nav>{children}</>}
