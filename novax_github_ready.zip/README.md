# NovaX Crypto Exchange — GitHub Ready

## Run locally

Requirements: Node.js 20+, PostgreSQL.

```bash
git clone YOUR_REPO_URL
cd novax-github-ready
npm install
```

Copy `.env.example` to `.env`, create a PostgreSQL database named `novax`, then:

```bash
npx prisma generate
npm run db:push
npm run db:seed
npm run dev
```

Open http://localhost:3000

### GitHub

```bash
git init
git add .
git commit -m "Initial NovaX exchange"
git branch -M main
git remote add origin YOUR_REPO_URL
git push -u origin main
```

## Important

This is a software MVP. Deposits/withdrawals and trading are database-level/demo functionality; no real blockchain assets are moved. A production exchange requires custody/blockchain integration, KYC/AML, security controls, monitoring, audits and jurisdiction-specific compliance.

Never commit `.env` or private keys.
